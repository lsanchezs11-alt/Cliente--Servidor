package org.vinni.servidor.gui;


import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * Author: Vinni
 */
public class PrincipalSrv extends javax.swing.JFrame {
    private final int PORT = 12345;
    private ServerSocket serverSocket;

    private List<ClienteHandler> clientesConectados = new ArrayList<>();

    public PrincipalSrv() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {
        this.setTitle("Servidor ...");

        bIniciar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        mensajesTxt = new JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        bIniciar.setFont(new java.awt.Font("Segoe UI", 0, 18));
        bIniciar.setText("INICIAR SERVIDOR");
        bIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bIniciarActionPerformed(evt);
            }
        });
        getContentPane().add(bIniciar);
        bIniciar.setBounds(100, 90, 250, 40);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setText("SERVIDOR TCP : HOEL");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(150, 10, 160, 17);

        mensajesTxt.setColumns(25);
        mensajesTxt.setRows(5);

        jScrollPane1.setViewportView(mensajesTxt);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(20, 160, 410, 70);

        setSize(new java.awt.Dimension(491, 290));
        setLocationRelativeTo(null);
    }// </editor-fold>

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalSrv().setVisible(true);
            }
        });
    }

    private void bIniciarActionPerformed(java.awt.event.ActionEvent evt) {
        iniciarServidor();
    }

    private void iniciarServidor() {
        JOptionPane.showMessageDialog(this, "Iniciando servidor");
        new Thread(new Runnable() {
            public void run() {
                try {
                    InetAddress addr = InetAddress.getLocalHost();
                    serverSocket = new ServerSocket(PORT);
                    mensajesTxt.append("Servidor TCP en ejecución: "+ addr + " ,Puerto " + serverSocket.getLocalPort()+ "\n");

                    while (true) {
                        Socket clientSocket = serverSocket.accept();

                        ClienteHandler handler = new ClienteHandler(clientSocket);
                        clientesConectados.add(handler);

                        new Thread(handler).start();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                    mensajesTxt.append("Error en el servidor: " + ex.getMessage() + "\n");
                }
            }
        }).start();
    }

    // MÉTODO MODIFICADO: Procesar el mensaje
    private synchronized void procesarMensaje(String mensaje, ClienteHandler remitente) {
        // Verificar si es un mensaje privado (formato: @nombreCliente:mensaje)
        if (mensaje.startsWith("@")) {
            enviarMensajePrivado(mensaje, remitente);
        } else {
            // Mensaje público a todos
            enviarATodos(remitente.getNombreCliente() + ": " + mensaje, remitente);
        }
    }

    // NUEVO MÉTODO: Enviar mensaje privado a un cliente específico
    private synchronized void enviarMensajePrivado(String mensaje, ClienteHandler remitente) {
        try {
            // Formato: @nombreDestino:mensaje
            int separador = mensaje.indexOf(":");
            if (separador == -1) {
                remitente.enviarMensaje("[ERROR] Formato incorrecto. Usa: @nombreCliente:mensaje");
                return;
            }

            String nombreDestino = mensaje.substring(1, separador); // Quita el @ y extrae el nombre
            String contenidoMensaje = mensaje.substring(separador + 1); // Extrae el mensaje

            mensajesTxt.append("[PRIVADO] " + remitente.getNombreCliente() + " → " + nombreDestino + ": " + contenidoMensaje + "\n");

            // Buscar el cliente destinatario
            boolean encontrado = false;
            for (ClienteHandler cliente : clientesConectados) {
                if (cliente.getNombreCliente().equals(nombreDestino)) {
                    cliente.enviarMensaje("[PRIVADO de " + remitente.getNombreCliente() + "]: " + contenidoMensaje);
                    remitente.enviarMensaje("[PRIVADO enviado a " + nombreDestino + "]: " + contenidoMensaje);
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                remitente.enviarMensaje("[ERROR] Cliente '" + nombreDestino + "' no encontrado");
            }

        } catch (Exception e) {
            remitente.enviarMensaje("[ERROR] Formato incorrecto. Usa: @nombreCliente:mensaje");
        }
    }

    // Enviar mensaje a todos los clientes
    private synchronized void enviarATodos(String mensaje, ClienteHandler remitente) {
        mensajesTxt.append("[PÚBLICO] " + mensaje + "\n");

        for (ClienteHandler cliente : clientesConectados) {
            cliente.enviarMensaje(mensaje);
        }
    }

    // NUEVO MÉTODO: Enviar lista de clientes conectados
    private synchronized void enviarListaClientes(ClienteHandler solicitante) {
        StringBuilder lista = new StringBuilder("[CLIENTES CONECTADOS]: ");
        for (ClienteHandler cliente : clientesConectados) {
            lista.append(cliente.getNombreCliente()).append(", ");
        }
        solicitante.enviarMensaje(lista.toString());
    }

    class ClienteHandler implements Runnable {
        private Socket clientSocket;
        private BufferedReader in;
        private PrintWriter out;
        private String nombreCliente;

        public ClienteHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public String getNombreCliente() {
            return nombreCliente;
        }

        public void enviarMensaje(String mensaje) {
            if (out != null) {
                out.println(mensaje);
            }
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                out = new PrintWriter(clientSocket.getOutputStream(), true);

                // NUEVO: Solicitar nombre al cliente
                out.println("Ingresa tu nombre:");
                nombreCliente = in.readLine();

                if (nombreCliente == null || nombreCliente.trim().isEmpty()) {
                    nombreCliente = clientSocket.getInetAddress().getHostAddress();
                }

                mensajesTxt.append("Cliente conectado: " + nombreCliente + "\n");
                enviarATodos("[SERVIDOR] " + nombreCliente + " se ha unido al chat", this);

                // Enviar lista de comandos
                out.println("[COMANDOS]: Escribe '@nombreCliente:mensaje' para mensaje privado, '/lista' para ver clientes");

                String linea;
                while ((linea = in.readLine()) != null) {
                    mensajesTxt.append(nombreCliente + ": " + linea + "\n");

                    // Comando especial para listar clientes
                    if (linea.equalsIgnoreCase("/lista")) {
                        enviarListaClientes(this);
                    } else {
                        // Procesar el mensaje (privado o público)
                        procesarMensaje(linea, this);
                    }
                }

            } catch (IOException ex) {
                ex.printStackTrace();
                mensajesTxt.append("Error con cliente: " + ex.getMessage() + "\n");
            } finally {
                clientesConectados.remove(this);
                if (nombreCliente != null) {
                    enviarATodos("[SERVIDOR] " + nombreCliente + " se ha desconectado", this);
                }
                try {
                    if (clientSocket != null && !clientSocket.isClosed()) {
                        clientSocket.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Variables declaration - do not modify
    private javax.swing.JButton bIniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextArea mensajesTxt;
    private javax.swing.JScrollPane jScrollPane1;
}